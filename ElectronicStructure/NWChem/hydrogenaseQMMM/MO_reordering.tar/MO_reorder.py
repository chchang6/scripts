#!/usr/bin/env python

import numpy
import re, sys
import pickle

def reorder(vec, plist, m):
   # vec is MO vector in list form. plist is pointer list. m is QMmap
   newvec = []
   counter = 1
   while counter < len(vec) + 1:
      for i in m:
         prepare_index = i[2]
         if prepare_index == counter:
            QM_index = i[1]
            QM_startindex = plist[QM_index-1]   # Math in next 4 lines due to 1-indexing for atoms, 0-indexing for Pylists.
            QM_endindex = plist[QM_index]
            newvec.extend(vec[QM_startindex:QM_endindex])
      counter += 1
   return newvec

RE1 = re.compile('MO vectors')
RE2 = re.compile('Number of vectors in set 1')
RE3 = re.compile('Number of vectors in set 2')
coeff_per_line = 4

# Get number translation from QM_prepare_atommap. [(QM number, prepare number)...]
#   Assumption that list elements are in QM order, i.e., that second member of tuple is
#   increasing by units monotonically.
file = open('QM_prepare_atommap', 'r')
QMmap = pickle.load(file)
file.close()

# Create list of indices where each atom's coefficients start.
basisdict = {'Fe':26, 'S':19, 'O':15, 'N':15, 'C':15, 'H':5, 'H_L':5}   # Number of coefficients for each element
gaspoints = [0]
pointer = 0
for i in QMmap:
   element = i[0]
   pointer += basisdict[element]
   gaspoints.append(pointer)

# Infile is formatted MO vector file with QM order, created from readmos.
infile = open(sys.argv[1], 'r')
data = infile.readlines()
infile.close()

# Outfile is formatted MO vector file with prepare (QMMM) order.
outfile = open(sys.argv[2], 'w')
set = ''
read = False
i = 0
while i < len(data):
   if RE2.search(data[i]):
      outfile.write(data[i])
      numset1 = int(re.sub('.+is[ ]*([0-9]+)', '\g<1>', data[i]))  # numset1 is the number of alpha MOs and coefficients
      if numset1 % coeff_per_line != 0:
         numrows1 = int(numset1/coeff_per_line) + 2  # Number of coefficient rows + MO label
      else:
         numrows1 = int(numset1/coeff_per_line) + 1  # Number of coefficient rows + MO label
   elif RE3.search(data[i]):
      outfile.write(data[i])
      numset2 = int(re.sub('.+is[ ]*([0-9]+)', '\g<1>', data[i]))
      if numset2 % coeff_per_line != 0:
         numrows2 = int(numset2/coeff_per_line) + 2  # Number of coefficient rows + MO label
      else:
         numrows2 = int(numset2/coeff_per_line) + 1  # Number of coefficient rows + MO label
   elif RE1.search(data[i]) and set == '':
      outfile.write(data[i])
      read = True
      set = 'alpha'
      i += 1
      continue
   elif RE1.search(data[i]) and set == 'alpha':
      outfile.write(data[i])
      read = True
      set = 'beta'
      i += 1
      continue
   elif read == True and set == 'alpha':
      for j in xrange(numset1):
         print j
         MO = data[i+j*numrows1]
         a = []
         for k in range(1, numrows1):
            if k < (numrows1 - 1): limit = coeff_per_line
            elif k == (numrows1 - 1) and numset1 % coeff_per_line == 0: limit = coeff_per_line
            elif k == (numrows1 - 1) and numset1 % coeff_per_line != 0: limit = numset1 % coeff_per_line
            else: raise ValueError('Problem with alpha conditional')
            for l in xrange(limit):
               a.append(data[i + j*numrows1 + k][l*20:(l+1)*20])
         b = reorder(a, gaspoints, QMmap)
         outfile.write(MO)
         for k in xrange(numrows1-1):
            if k < (numrows1-2): limit = coeff_per_line
            else: limit = numset1 % coeff_per_line
            for l in xrange(limit):
               outfile.write(b[k*coeff_per_line+l])
            outfile.write('\n')
      read = False
      i += numset1*numrows1
      continue
   elif read == True and set == 'beta':
      for j in xrange(numset2):
         print j
         MO = data[i+j*numrows2]
         a = []
         for k in range(1,numrows2):
            if k < (numrows2 - 1): limit = coeff_per_line
            elif k == (numrows2 - 1) and numset2 % coeff_per_line == 0: limit = coeff_per_line
            elif k == (numrows2 - 1) and numset2 % coeff_per_line != 0: limit = numset2 % coeff_per_line
            else: raise ValueError('Problem with beta conditional')
            for l in xrange(limit):
               a.append(data[i+j*numrows2+k][l*20:(l+1)*20])
         b = reorder(a, gaspoints, QMmap)
         outfile.write(MO)
         for k in xrange(numrows2-1):
            if k < (numrows2-2): limit = coeff_per_line
            else: limit = numset2 % coeff_per_line
            for l in xrange(limit):
               outfile.write(b[k*coeff_per_line+l])
            outfile.write('\n')
      read = False
      i += numset2*numrows2
      continue
   else:
      outfile.write(data[i])
   i += 1
outfile.close()
