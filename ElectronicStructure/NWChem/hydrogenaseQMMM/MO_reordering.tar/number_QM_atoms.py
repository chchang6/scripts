#!/usr/bin/env python
#    Script to insert numbering from master.nw atomic coordinate sections.

file = open('atoms_QMorder', 'r')
data = file.readlines()
file.close()

new = []
i= 1
for j in data:
   if j[0:3] == 'Fe ' or j[0:3] == 'S  ' or j[0:3] == 'O  ' or j[0:3] == 'N  ' or j[0:3] == 'C  ' or j[0:3] == 'H  ' or j[0:3] == 'H_L':
      new.append(str(i) + '   ' + j)
      i += 1
   else:
      new.append(j)

file = open('newQMorder', 'w')
for i in new:
   file.write(i)
file.close()
