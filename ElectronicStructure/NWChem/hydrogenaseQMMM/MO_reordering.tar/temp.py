#!/usr/bin/env python

import pickle

file = open('QM_prepare_atommap', 'r')
data = pickle.load(file)
file.close()

test = []
for i in data:
   if i[1] in test: print 'uhoh'
   else: test.append(i[1])
print test

for i in data:
   if i[2] in test: test.remove(i[2])
   else: print 'uhoh: ' + str(i[2]) + ' not in test!'

print len(test)
