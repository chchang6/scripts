#!/usr/bin/env python
#   Script to generate mapping of atoms from QM order to prepare order.
#   Output is simple pickled file containing list of 2-tuples, (QM number, prepare number).

import hashlib
import pickle

# Get data
file1 = open('atoms_QMorder', 'r')
data1 = file1.readlines()
file1.close()

file2 = open('CpI_O_OR_OOO_QMMM-active.pdb', 'r')
data2 = file2.readlines()
file2.close()

# Make dict with prepare atom coordinate signatures and numbering.
prepare_dict = {}
for i in xrange(len(data2)):
   temp = data2[i].split()
   atom = temp[2]
   x = temp[3]
   y = temp[4]
   z = temp[5]
   prepare_dict[hashlib.new('md5', atom + x + y + z).hexdigest()] = i+1
# Go through QM order and compare coordinates with prepare atom coordinates.
map = []
for i in data1:
   try:
      temp = i.split()
      QM_number = int(temp[0])
      atom = temp[1]
      x = temp[2]
      y = temp[3]
      z = temp[4]
      prepare_number = prepare_dict[hashlib.new('md5', atom + x + y + z).hexdigest()]
      map.append( (atom, QM_number, prepare_number) )
   except ValueError: continue  # Line splits, but data nonsense (non-coordinate line)
   except IndexError: continue  # Line doesn't split
file3 = open('QM_prepare_atommap', 'w')
pickle.dump( map, file3)
file3.close()
